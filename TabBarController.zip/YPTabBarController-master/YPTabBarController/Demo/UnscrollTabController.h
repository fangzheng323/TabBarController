//
//  UnscrollTabController.h
//  YPTabBarController
//
//  Created by 喻平 on 16/5/25.
//  Copyright © 2016年 YPTabBarController. All rights reserved.
//

#import "YPTabBarController.h"

@interface UnscrollTabController : YPTabBarController

@end
